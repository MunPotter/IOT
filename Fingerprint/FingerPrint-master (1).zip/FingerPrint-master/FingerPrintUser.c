
#include "FingerPrint.h"



void	FingerPrint_Detect(uint16_t	Location)
{
	osDelay(10);	
}
